﻿//Referiing the Namespace where the Calc_Math is located.
using Method_Class_Assignment;

//Instance of the Class Calc_Math
Calc_Math myCalc = new Calc_Math();

//Calling the and passing paramters for the Calc method
myCalc.Calc( x:25, y: 6);

//Atention: This is using .NET 6 Framework so there is no need to declare the Main mmethod anymore  

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Method_Class_Assignment
{
    internal class Calc_Math
    {
        public void Calc(int x, int y)
        {
            x += 30;
            Console.WriteLine("This is the value of y: {0}", y);
        }
    }
}
